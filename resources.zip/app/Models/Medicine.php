<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medicine extends Model
{
    protected $fillable = [
        'name',
        'price',
        'description',
        'expired',
        'medicine_image'
    ];
}
